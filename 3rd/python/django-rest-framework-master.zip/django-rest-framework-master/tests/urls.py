"""
Blank URLConf just to keep the test suite happy
"""
from django.conf.urls import patterns

urlpatterns = patterns('')
